/*******************************************************************************
* Copyright (c) 2019 IBM Corporation and others.
* All rights reserved. This program and the accompanying materials
* are made available under the terms of the Eclipse Public License v2.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v20.html
*
* Contributors:
*     IBM Corporation - initial API and implementation
*******************************************************************************/
export declare class HttpPostOutputQueue {
    private static readonly MAX_ACTIVE_REQUESTS;
    private readonly _queue;
    private readonly _serverBaseUrl;
    private _activeRequests;
    private _disposed;
    private readonly _failureDelay;
    constructor(serverBaseUrl: string);
    informStateChangeAsync(): Promise<void>;
    addToQueue(projectId: string, timestamp: number, base64Compressed: string[]): void;
    dispose(): void;
    /** Remove any chunk groups that have already sent all their chunks. */
    private cleanupChunkGroups;
    /** Returns next available piece of work from the queue, or null if no work available. */
    private getNextPieceOfWork;
    private doHttpPost;
    private resortQueue;
    private sendRequestAsync;
}
