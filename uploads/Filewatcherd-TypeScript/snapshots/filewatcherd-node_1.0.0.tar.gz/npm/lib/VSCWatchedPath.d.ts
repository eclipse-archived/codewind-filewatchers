import { ProjectToWatch } from "./ProjectToWatch";
import { VSCodeResourceWatchService } from "./VSCodeResourceWatchService";
import { WatchEventEntry } from "./WatchEventEntry";
export declare class VSCWatchedPath {
    private readonly _pathInNormalizedForm;
    private readonly _pathFilter;
    private readonly _parent;
    constructor(pathRoot: string, ptw: ProjectToWatch, parent: VSCodeResourceWatchService);
    receiveFileChanges(entries: WatchEventEntry[]): void;
    dispose(): void;
}
